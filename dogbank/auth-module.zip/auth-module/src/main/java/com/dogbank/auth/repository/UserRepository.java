package com.dogbank.auth.repository;

import com.dogbank.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @Query("SELECT u FROM User u WHERE TRIM(u.cpf) = :cpf")
    Optional<User> findByCpf(@Param("cpf") String cpf);

    @Query("SELECT u FROM User u WHERE TRIM(u.chavePix) = :chavePix")
    Optional<User> findByChavePix(@Param("chavePix") String chavePix);
}
